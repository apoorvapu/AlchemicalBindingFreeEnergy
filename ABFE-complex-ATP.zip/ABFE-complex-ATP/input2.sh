!/bin/bash
source /home/purohit.52/gromacs-2022/gmx_installed_here/bin/GMXRC




for d in lambda.06 lambda.07 lambda.08 lambda.26 lambda.34 ; do
  d1=$(basename $d)
  lam="${d1##*.}"

  cd $d

  mkdir NVT
  cd NVT

  gmx grompp -maxwarn 1 -f ../../MDP/nvt.$lam.mdp -c ../../enmin2.gro -r ../../enmin2.gro -p ../../gromacs.top -o nvt.tpr
  gmx mdrun -nt 8 -gpu_id 0 -nb gpu -pme gpu -bonded gpu  -stepout 1000000 -s nvt.tpr -deffnm nvt 

  cd ../

  mkdir NPT
  cd NPT

  gmx grompp -maxwarn 1 -f ../../MDP/npt.$lam.mdp -t ../NVT/nvt.cpt -c ../NVT/nvt.gro -r ../NVT/nvt.gro -p ../../gromacs.top -o npt.tpr
  gmx mdrun -nt 8 -gpu_id 0 -nb gpu -pme gpu -bonded gpu  -stepout 1000000 -s npt.tpr -deffnm npt

  cd ../

  mkdir PROD
  cd PROD
 
  gmx grompp -maxwarn 1 -f ../../MDP/prod.$lam.mdp -t ../NPT/npt.cpt -c ../NPT/npt.gro -r ../NPT/npt.gro -p ../../gromacs.top -o prod.tpr


 
  cd ../../
done

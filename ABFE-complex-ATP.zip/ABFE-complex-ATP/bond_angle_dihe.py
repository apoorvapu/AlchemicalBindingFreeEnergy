#!/usr/bin/env python
import math

def dist(A, B):
    xdif = (A[0] - B[0])**2
    ydif = (A[1] - B[1])**2
    zdif = (A[2] - B[2])**2
    return math.sqrt(xdif + ydif + zdif)

def ang(A, B, C):
    xba = A[0] - B[0]
    yba = A[1] - B[1]
    zba = A[2] - B[2]
    xbc = C[0] - B[0]
    ybc = C[1] - B[1]
    zbc = C[2] - B[2]
    dot = (xba*xbc) + (yba*ybc) + (zba*zbc)
    d_ab = dist(A, B)
    d_bc = dist(B, C)
    return (math.acos(dot/(d_ab*d_bc))) * 180 / math.pi

def dihe(A, B, C, D):
    xba = A[0] - B[0]
    yba = A[1] - B[1]
    zba = A[2] - B[2]
    xbc = C[0] - B[0]
    ybc = C[1] - B[1]
    zbc = C[2] - B[2]
    xcb = B[0] - C[0]
    ycb = B[1] - C[1]
    zcb = B[2] - C[2]
    xcd = D[0] - C[0]
    ycd = D[1] - C[1]
    zcd = D[2] - C[2]

    # Cross vectors
    Cbabc_x = (yba * zbc) - (zba * ybc)
    Cbabc_y = (zba * xbc) - (xba * zbc)
    Cbabc_z = (xba * ybc) - (yba * xbc)

    Ccbcd_x = (ycb * zcd) - (zcb * ycd)
    Ccbcd_y = (zcb * xcd) - (xcb * zcd)
    Ccbcd_z = (xcb * ycd) - (ycb * xcd)

    dot = (Cbabc_x * Ccbcd_x) + (Cbabc_y * Ccbcd_y) + (Cbabc_z * Ccbcd_z)
    Den = math.sqrt(Cbabc_x**2 + Cbabc_y**2 + Cbabc_z**2) * math.sqrt(Ccbcd_x**2     + Ccbcd_y**2 + Ccbcd_z**2 )

    i = yba * zcd - zba * ycd
    j = zba * xcd - xba * zcd
    k = xba * ycd - yba * xcd
    f = i * xbc + j * ybc + k * zbc

    if f >= 0:
        return (math.acos(dot / Den)) * 180 / math.pi
    else:
        return -1 * ((math.acos(dot / Den)) * 180 / math.pi)


# coming from ./BoreschrestraintsAtoms.sh 
print("ATPA: add to topology file")
atomA= 31
A=[ 4.473 , 4.107 , 4.251 ]
atomB= 25
B=[ 4.385 , 3.814 , 4.473 ]
atomC= 22
C=[ 4.608 , 3.788 , 4.458 ]
atoma= 751
a=[ 4.604 , 4.487 , 4.545 ]
atomb= 728
b=[ 4.218 , 4.613 , 4.898 ]
atomc= 703
c=[ 4.285 , 4.075 , 4.861 ]

print("[ intermolecular_interactions]")
# calculate bond distance
distance = dist(a, A)
print("[ bonds ]")
print("; ai     aj    type   bA      kA     bB      kB")
print(atoma ,  " ", atomA ," 6 ", distance ,  " 0.0 "   , distance ,  " 4184.0 ")

# calculate angle
print(" ")
print("[ angles ]")
print("; ai     aj    ak     type    thA      fcA        thB      fcB")   
angle = ang(b, a, A)
print(atomb , atoma , atomA ," 1 " , angle, " 0.0 " , angle, " 41.84 ")

angle = ang(a, A, B)
print(atoma , atomA , atomB ," 1 " , angle, " 0.0 " , angle, " 41.84 ")

# calculate dihedral
print(" ")
print("[ dihedrals ]") 
print("; ai     aj    ak    al    type     thA      fcA       thB      fcB")  
dihedral = dihe(c, b, a, A)
print(atomc , atomb , atoma , atomA ," 2 " , dihedral, " 0.0 " , dihedral, " 41.84 ")

dihedral = dihe(b, a, A, B)
print(atomb , atoma , atomA , atomB ," 2 " , dihedral, " 0.0 " , dihedral, " 41.84 ")

dihedral = dihe(a, A, B, C)
print(atoma , atomA , atomB , atomC ," 2 " , dihedral, " 0.0 " , dihedral, " 41.84 ")


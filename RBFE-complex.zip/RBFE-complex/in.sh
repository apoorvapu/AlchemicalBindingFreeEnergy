!/bin/bash
source /home/purohit.52/gromacs-2022/gmx_installed_here/bin/GMXRC

#gmx editconf -f solv_ions.gro -o conf.gro -resnr 1  #renumber all atoms after adding mg and na in between 

gmx grompp -maxwarn 1 -f minim.mdp -c gromacs.gro -p gromacs.top -o enmin.tpr
gmx mdrun -v -nt 8 -s enmin.tpr -deffnm enmin

gmx grompp -maxwarn 1 -f minim_cg.mdp -c enmin.gro -p gromacs.top -o enmin2.tpr
gmx mdrun -v -nt 8 -s enmin2.tpr -deffnm enmin2
 

!/bin/bash
source /home/purohit.52/gromacs-2022/gmx_installed_here/bin/GMXRC
gmx bar -f dHdl_files/dhdl*.xvg -temp 300.0 
 

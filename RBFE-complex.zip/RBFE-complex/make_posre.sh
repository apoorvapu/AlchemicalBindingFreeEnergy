grep ' CA ' gromacs.gro | awk ' { print "  ", $3, "  1 ", "1000", "1000", "1000"; }' > posre.itp


 

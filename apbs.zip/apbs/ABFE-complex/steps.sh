#! /bin/bash

module load intel/2021.3.0
module load  gromacs/2022.1
gmx editconf -f prod.tpr -mead prod.pqr
 
sed -i 's\NALAA\ ALA \g' *.pqr  
sed -i 's\NARGA\ ARG \g' *.pqr  
sed -i 's\NASNA\ ASN \g' *.pqr  
sed -i 's\NASPA\ ASP \g' *.pqr  
sed -i 's\NCYSA\ CYS \g' *.pqr  
sed -i 's\NGLNA\ GLN \g' *.pqr  
sed -i 's\NGLUA\ GLU \g' *.pqr  
sed -i 's\NGLYA\ GLY \g' *.pqr  
sed -i 's\NHISA\ HIS \g' *.pqr  
sed -i 's\NILEA\ ILE \g' *.pqr  
sed -i 's\NLEUA\ LEU \g' *.pqr  
sed -i 's\NLYSA\ LYS \g' *.pqr  
sed -i 's\NMETA\ MET \g' *.pqr  
sed -i 's\NPHEA\ PHE \g' *.pqr  
sed -i 's\NPROA\ PRO \g' *.pqr  
sed -i 's\NSERA\ SER \g' *.pqr  
sed -i 's\NTHRA\ THR \g' *.pqr  
sed -i 's\NTRPA\ TRP \g' *.pqr  
sed -i 's\NTYRA\ TYR \g' *.pqr  
sed -i 's\NVALA\ VAL \g' *.pqr  
sed -i 's\NALAB\ ALA \g' *.pqr  
sed -i 's\NARGB\ ARG \g' *.pqr  
sed -i 's\NASNB\ ASN \g' *.pqr  
sed -i 's\NASPB\ ASP \g' *.pqr  
sed -i 's\NCYSB\ CYS \g' *.pqr  
sed -i 's\NGLNB\ GLN \g' *.pqr  
sed -i 's\NGLUB\ GLU \g' *.pqr  
sed -i 's\NGLYB\ GLY \g' *.pqr  
sed -i 's\NHISB\ HIS \g' *.pqr  
sed -i 's\NILEB\ ILE \g' *.pqr  
sed -i 's\NLEUB\ LEU \g' *.pqr  
sed -i 's\NLYSB\ LYS \g' *.pqr  
sed -i 's\NMETB\ MET \g' *.pqr  
sed -i 's\NPHEB\ PHE \g' *.pqr  
sed -i 's\NPROB\ PRO \g' *.pqr  
sed -i 's\NSERB\ SER \g' *.pqr  
sed -i 's\NTHRB\ THR \g' *.pqr  
sed -i 's\NTRPB\ TRP \g' *.pqr  
sed -i 's\NTYRB\ TYR \g' *.pqr  
sed -i 's\NVALB\ VAL \g' *.pqr  
sed -i 's\NALAC\ ALA \g' *.pqr  
sed -i 's\NARGC\ ARG \g' *.pqr  
sed -i 's\NASNC\ ASN \g' *.pqr  
sed -i 's\NASPC\ ASP \g' *.pqr  
sed -i 's\NCYSC\ CYS \g' *.pqr  
sed -i 's\NGLNC\ GLN \g' *.pqr  
sed -i 's\NGLUC\ GLU \g' *.pqr  
sed -i 's\NGLYC\ GLY \g' *.pqr  
sed -i 's\NHISC\ HIS \g' *.pqr  
sed -i 's\NILEC\ ILE \g' *.pqr  
sed -i 's\NLEUC\ LEU \g' *.pqr  
sed -i 's\NLYSC\ LYS \g' *.pqr  
sed -i 's\NMETC\ MET \g' *.pqr  
sed -i 's\NPHEC\ PHE \g' *.pqr  
sed -i 's\NPROC\ PRO \g' *.pqr  
sed -i 's\NSERC\ SER \g' *.pqr  
sed -i 's\NTHRC\ THR \g' *.pqr  
sed -i 's\NTRPC\ TRP \g' *.pqr  
sed -i 's\NTYRC\ TYR \g' *.pqr  
sed -i 's\NVALC\ VAL \g' *.pqr  
sed -i 's\NALAD\ ALA \g' *.pqr  
sed -i 's\NARGD\ ARG \g' *.pqr  
sed -i 's\NASND\ ASN \g' *.pqr  
sed -i 's\NASPD\ ASP \g' *.pqr  
sed -i 's\NCYSD\ CYS \g' *.pqr  
sed -i 's\NGLND\ GLN \g' *.pqr  
sed -i 's\NGLUD\ GLU \g' *.pqr  
sed -i 's\NGLYD\ GLY \g' *.pqr  
sed -i 's\NHISD\ HIS \g' *.pqr  
sed -i 's\NILED\ ILE \g' *.pqr  
sed -i 's\NLEUD\ LEU \g' *.pqr  
sed -i 's\NLYSD\ LYS \g' *.pqr  
sed -i 's\NMETD\ MET \g' *.pqr  
sed -i 's\NPHED\ PHE \g' *.pqr  
sed -i 's\NPROD\ PRO \g' *.pqr  
sed -i 's\NSERD\ SER \g' *.pqr  
sed -i 's\NTHRD\ THR \g' *.pqr  
sed -i 's\NTRPD\ TRP \g' *.pqr  
sed -i 's\NTYRD\ TYR \g' *.pqr  
sed -i 's\NVALD\ VAL \g' *.pqr  
sed -i 's\NALAE\ ALA \g' *.pqr  
sed -i 's\NARGE\ ARG \g' *.pqr  
sed -i 's\NASNE\ ASN \g' *.pqr  
sed -i 's\NASPE\ ASP \g' *.pqr  
sed -i 's\NCYSE\ CYS \g' *.pqr  
sed -i 's\NGLNE\ GLN \g' *.pqr  
sed -i 's\NGLUE\ GLU \g' *.pqr  
sed -i 's\NGLYE\ GLY \g' *.pqr  
sed -i 's\NHISE\ HIS \g' *.pqr  
sed -i 's\NILEE\ ILE \g' *.pqr  
sed -i 's\NLEUE\ LEU \g' *.pqr  
sed -i 's\NLYSE\ LYS \g' *.pqr  
sed -i 's\NMETE\ MET \g' *.pqr  
sed -i 's\NPHEE\ PHE \g' *.pqr  
sed -i 's\NPROE\ PRO \g' *.pqr  
sed -i 's\NSERE\ SER \g' *.pqr  
sed -i 's\NTHRE\ THR \g' *.pqr  
sed -i 's\NTRPE\ TRP \g' *.pqr  
sed -i 's\NTYRE\ TYR \g' *.pqr  
sed -i 's\NVALE\ VAL \g' *.pqr  
sed -i 's\NALAF\ ALA \g' *.pqr  
sed -i 's\NARGF\ ARG \g' *.pqr  
sed -i 's\NASNF\ ASN \g' *.pqr  
sed -i 's\NASPF\ ASP \g' *.pqr  
sed -i 's\NCYSF\ CYS \g' *.pqr  
sed -i 's\NGLNF\ GLN \g' *.pqr  
sed -i 's\NGLUF\ GLU \g' *.pqr  
sed -i 's\NGLYF\ GLY \g' *.pqr  
sed -i 's\NHISF\ HIS \g' *.pqr  
sed -i 's\NILEF\ ILE \g' *.pqr  
sed -i 's\NLEUF\ LEU \g' *.pqr  
sed -i 's\NLYSF\ LYS \g' *.pqr  
sed -i 's\NMETF\ MET \g' *.pqr  
sed -i 's\NPHEF\ PHE \g' *.pqr  
sed -i 's\NPROF\ PRO \g' *.pqr  
sed -i 's\NSERF\ SER \g' *.pqr  
sed -i 's\NTHRF\ THR \g' *.pqr  
sed -i 's\NTRPF\ TRP \g' *.pqr  
sed -i 's\NTYRF\ TYR \g' *.pqr  
sed -i 's\NVALF\ VAL \g' *.pqr  

sed -i 's\CALAA\ ALA \g' *.pqr  
sed -i 's\CARGA\ ARG \g' *.pqr  
sed -i 's\CASNA\ ASN \g' *.pqr  
sed -i 's\CASPA\ ASP \g' *.pqr  
sed -i 's\CCYSA\ CYS \g' *.pqr  
sed -i 's\CGLNA\ GLN \g' *.pqr  
sed -i 's\CGLUA\ GLU \g' *.pqr  
sed -i 's\CGLYA\ GLY \g' *.pqr  
sed -i 's\CHISA\ HIS \g' *.pqr  
sed -i 's\CILEA\ ILE \g' *.pqr  
sed -i 's\CLEUA\ LEU \g' *.pqr  
sed -i 's\CLYSA\ LYS \g' *.pqr  
sed -i 's\CMETA\ MET \g' *.pqr  
sed -i 's\CPHEA\ PHE \g' *.pqr  
sed -i 's\CPROA\ PRO \g' *.pqr  
sed -i 's\CSERA\ SER \g' *.pqr  
sed -i 's\CTHRA\ THR \g' *.pqr  
sed -i 's\CTRPA\ TRP \g' *.pqr  
sed -i 's\CTYRA\ TYR \g' *.pqr  
sed -i 's\CVALA\ VAL \g' *.pqr  
sed -i 's\CALAB\ ALA \g' *.pqr  
sed -i 's\CARGB\ ARG \g' *.pqr  
sed -i 's\CASNB\ ASN \g' *.pqr  
sed -i 's\CASPB\ ASP \g' *.pqr  
sed -i 's\CCYSB\ CYS \g' *.pqr  
sed -i 's\CGLNB\ GLN \g' *.pqr  
sed -i 's\CGLUB\ GLU \g' *.pqr  
sed -i 's\CGLYB\ GLY \g' *.pqr  
sed -i 's\CHISB\ HIS \g' *.pqr  
sed -i 's\CILEB\ ILE \g' *.pqr  
sed -i 's\CLEUB\ LEU \g' *.pqr  
sed -i 's\CLYSB\ LYS \g' *.pqr  
sed -i 's\CMETB\ MET \g' *.pqr  
sed -i 's\CPHEB\ PHE \g' *.pqr  
sed -i 's\CPROB\ PRO \g' *.pqr  
sed -i 's\CSERB\ SER \g' *.pqr  
sed -i 's\CTHRB\ THR \g' *.pqr  
sed -i 's\CTRPB\ TRP \g' *.pqr  
sed -i 's\CTYRB\ TYR \g' *.pqr  
sed -i 's\CVALB\ VAL \g' *.pqr  
sed -i 's\CALAC\ ALA \g' *.pqr  
sed -i 's\CARGC\ ARG \g' *.pqr  
sed -i 's\CASNC\ ASN \g' *.pqr  
sed -i 's\CASPC\ ASP \g' *.pqr  
sed -i 's\CCYSC\ CYS \g' *.pqr  
sed -i 's\CGLNC\ GLN \g' *.pqr  
sed -i 's\CGLUC\ GLU \g' *.pqr  
sed -i 's\CGLYC\ GLY \g' *.pqr  
sed -i 's\CHISC\ HIS \g' *.pqr  
sed -i 's\CILEC\ ILE \g' *.pqr  
sed -i 's\CLEUC\ LEU \g' *.pqr  
sed -i 's\CLYSC\ LYS \g' *.pqr  
sed -i 's\CMETC\ MET \g' *.pqr  
sed -i 's\CPHEC\ PHE \g' *.pqr  
sed -i 's\CPROC\ PRO \g' *.pqr  
sed -i 's\CSERC\ SER \g' *.pqr  
sed -i 's\CTHRC\ THR \g' *.pqr  
sed -i 's\CTRPC\ TRP \g' *.pqr  
sed -i 's\CTYRC\ TYR \g' *.pqr  
sed -i 's\CVALC\ VAL \g' *.pqr  
sed -i 's\CALAD\ ALA \g' *.pqr  
sed -i 's\CARGD\ ARG \g' *.pqr  
sed -i 's\CASND\ ASN \g' *.pqr  
sed -i 's\CASPD\ ASP \g' *.pqr  
sed -i 's\CCYSD\ CYS \g' *.pqr  
sed -i 's\CGLND\ GLN \g' *.pqr  
sed -i 's\CGLUD\ GLU \g' *.pqr  
sed -i 's\CGLYD\ GLY \g' *.pqr  
sed -i 's\CHISD\ HIS \g' *.pqr  
sed -i 's\CILED\ ILE \g' *.pqr  
sed -i 's\CLEUD\ LEU \g' *.pqr  
sed -i 's\CLYSD\ LYS \g' *.pqr  
sed -i 's\CMETD\ MET \g' *.pqr  
sed -i 's\CPHED\ PHE \g' *.pqr  
sed -i 's\CPROD\ PRO \g' *.pqr  
sed -i 's\CSERD\ SER \g' *.pqr  
sed -i 's\CTHRD\ THR \g' *.pqr  
sed -i 's\CTRPD\ TRP \g' *.pqr  
sed -i 's\CTYRD\ TYR \g' *.pqr  
sed -i 's\CVALD\ VAL \g' *.pqr  
sed -i 's\CALAE\ ALA \g' *.pqr  
sed -i 's\CARGE\ ARG \g' *.pqr  
sed -i 's\CASNE\ ASN \g' *.pqr  
sed -i 's\CASPE\ ASP \g' *.pqr  
sed -i 's\CCYSE\ CYS \g' *.pqr  
sed -i 's\CGLNE\ GLN \g' *.pqr  
sed -i 's\CGLUE\ GLU \g' *.pqr  
sed -i 's\CGLYE\ GLY \g' *.pqr  
sed -i 's\CHISE\ HIS \g' *.pqr  
sed -i 's\CILEE\ ILE \g' *.pqr  
sed -i 's\CLEUE\ LEU \g' *.pqr  
sed -i 's\CLYSE\ LYS \g' *.pqr  
sed -i 's\CMETE\ MET \g' *.pqr  
sed -i 's\CPHEE\ PHE \g' *.pqr  
sed -i 's\CPROE\ PRO \g' *.pqr  
sed -i 's\CSERE\ SER \g' *.pqr  
sed -i 's\CTHRE\ THR \g' *.pqr  
sed -i 's\CTRPE\ TRP \g' *.pqr  
sed -i 's\CTYRE\ TYR \g' *.pqr  
sed -i 's\CVALE\ VAL \g' *.pqr  
sed -i 's\CALAF\ ALA \g' *.pqr  
sed -i 's\CARGF\ ARG \g' *.pqr  
sed -i 's\CASNF\ ASN \g' *.pqr  
sed -i 's\CASPF\ ASP \g' *.pqr  
sed -i 's\CCYSF\ CYS \g' *.pqr  
sed -i 's\CGLNF\ GLN \g' *.pqr  
sed -i 's\CGLUF\ GLU \g' *.pqr  
sed -i 's\CGLYF\ GLY \g' *.pqr  
sed -i 's\CHISF\ HIS \g' *.pqr  
sed -i 's\CILEF\ ILE \g' *.pqr  
sed -i 's\CLEUF\ LEU \g' *.pqr  
sed -i 's\CLYSF\ LYS \g' *.pqr  
sed -i 's\CMETF\ MET \g' *.pqr  
sed -i 's\CPHEF\ PHE \g' *.pqr  
sed -i 's\CPROF\ PRO \g' *.pqr  
sed -i 's\CSERF\ SER \g' *.pqr  
sed -i 's\CTHRF\ THR \g' *.pqr  
sed -i 's\CTRPF\ TRP \g' *.pqr  
sed -i 's\CTYRF\ TYR \g' *.pqr  
sed -i 's\CVALF\ VAL \g' *.pqr  

sed -i 's\ALAA\ALA \g' *.pqr  
sed -i 's\ARGA\ARG \g' *.pqr  
sed -i 's\ASNA\ASN \g' *.pqr  
sed -i 's\ASPA\ASP \g' *.pqr  
sed -i 's\CYSA\CYS \g' *.pqr  
sed -i 's\GLNA\GLN \g' *.pqr  
sed -i 's\GLUA\GLU \g' *.pqr  
sed -i 's\GLYA\GLY \g' *.pqr  
sed -i 's\HISA\HIS \g' *.pqr  
sed -i 's\ILEA\ILE \g' *.pqr  
sed -i 's\LEUA\LEU \g' *.pqr  
sed -i 's\LYSA\LYS \g' *.pqr  
sed -i 's\META\MET \g' *.pqr  
sed -i 's\PHEA\PHE \g' *.pqr  
sed -i 's\PROA\PRO \g' *.pqr  
sed -i 's\SERA\SER \g' *.pqr  
sed -i 's\THRA\THR \g' *.pqr  
sed -i 's\TRPA\TRP \g' *.pqr  
sed -i 's\TYRA\TYR \g' *.pqr  
sed -i 's\VALA\VAL \g' *.pqr  
sed -i 's\ALAB\ALA \g' *.pqr  
sed -i 's\ARGB\ARG \g' *.pqr  
sed -i 's\ASNB\ASN \g' *.pqr  
sed -i 's\ASPB\ASP \g' *.pqr  
sed -i 's\CYSB\CYS \g' *.pqr  
sed -i 's\GLNB\GLN \g' *.pqr  
sed -i 's\GLUB\GLU \g' *.pqr  
sed -i 's\GLYB\GLY \g' *.pqr  
sed -i 's\HISB\HIS \g' *.pqr  
sed -i 's\ILEB\ILE \g' *.pqr  
sed -i 's\LEUB\LEU \g' *.pqr  
sed -i 's\LYSB\LYS \g' *.pqr  
sed -i 's\METB\MET \g' *.pqr  
sed -i 's\PHEB\PHE \g' *.pqr  
sed -i 's\PROB\PRO \g' *.pqr  
sed -i 's\SERB\SER \g' *.pqr  
sed -i 's\THRB\THR \g' *.pqr  
sed -i 's\TRPB\TRP \g' *.pqr  
sed -i 's\TYRB\TYR \g' *.pqr  
sed -i 's\VALB\VAL \g' *.pqr  
sed -i 's\ALAC\ALA \g' *.pqr  
sed -i 's\ARGC\ARG \g' *.pqr  
sed -i 's\ASNC\ASN \g' *.pqr  
sed -i 's\ASPC\ASP \g' *.pqr  
sed -i 's\CYSC\CYS \g' *.pqr  
sed -i 's\GLNC\GLN \g' *.pqr  
sed -i 's\GLUC\GLU \g' *.pqr  
sed -i 's\GLYC\GLY \g' *.pqr  
sed -i 's\HISC\HIS \g' *.pqr  
sed -i 's\ILEC\ILE \g' *.pqr  
sed -i 's\LEUC\LEU \g' *.pqr  
sed -i 's\LYSC\LYS \g' *.pqr  
sed -i 's\METC\MET \g' *.pqr  
sed -i 's\PHEC\PHE \g' *.pqr  
sed -i 's\PROC\PRO \g' *.pqr  
sed -i 's\SERC\SER \g' *.pqr  
sed -i 's\THRC\THR \g' *.pqr  
sed -i 's\TRPC\TRP \g' *.pqr  
sed -i 's\TYRC\TYR \g' *.pqr  
sed -i 's\VALC\VAL \g' *.pqr  
sed -i 's\ALAD\ALA \g' *.pqr  
sed -i 's\ARGD\ARG \g' *.pqr  
sed -i 's\ASND\ASN \g' *.pqr  
sed -i 's\ASPD\ASP \g' *.pqr  
sed -i 's\CYSD\CYS \g' *.pqr  
sed -i 's\GLND\GLN \g' *.pqr  
sed -i 's\GLUD\GLU \g' *.pqr  
sed -i 's\GLYD\GLY \g' *.pqr  
sed -i 's\HISD\HIS \g' *.pqr  
sed -i 's\ILED\ILE \g' *.pqr  
sed -i 's\LEUD\LEU \g' *.pqr  
sed -i 's\LYSD\LYS \g' *.pqr  
sed -i 's\METD\MET \g' *.pqr  
sed -i 's\PHED\PHE \g' *.pqr  
sed -i 's\PROD\PRO \g' *.pqr  
sed -i 's\SERD\SER \g' *.pqr  
sed -i 's\THRD\THR \g' *.pqr  
sed -i 's\TRPD\TRP \g' *.pqr  
sed -i 's\TYRD\TYR \g' *.pqr  
sed -i 's\VALD\VAL \g' *.pqr  
sed -i 's\ALAE\ALA \g' *.pqr  
sed -i 's\ARGE\ARG \g' *.pqr  
sed -i 's\ASNE\ASN \g' *.pqr  
sed -i 's\ASPE\ASP \g' *.pqr  
sed -i 's\CYSE\CYS \g' *.pqr  
sed -i 's\GLNE\GLN \g' *.pqr  
sed -i 's\GLUE\GLU \g' *.pqr  
sed -i 's\GLYE\GLY \g' *.pqr  
sed -i 's\HISE\HIS \g' *.pqr  
sed -i 's\ILEE\ILE \g' *.pqr  
sed -i 's\LEUE\LEU \g' *.pqr  
sed -i 's\LYSE\LYS \g' *.pqr  
sed -i 's\METE\MET \g' *.pqr  
sed -i 's\PHEE\PHE \g' *.pqr  
sed -i 's\PROE\PRO \g' *.pqr  
sed -i 's\SERE\SER \g' *.pqr  
sed -i 's\THRE\THR \g' *.pqr  
sed -i 's\TRPE\TRP \g' *.pqr  
sed -i 's\TYRE\TYR \g' *.pqr  
sed -i 's\VALE\VAL \g' *.pqr  
sed -i 's\ALAF\ALA \g' *.pqr  
sed -i 's\ARGF\ARG \g' *.pqr  
sed -i 's\ASNF\ASN \g' *.pqr  
sed -i 's\ASPF\ASP \g' *.pqr  
sed -i 's\CYSF\CYS \g' *.pqr  
sed -i 's\GLNF\GLN \g' *.pqr  
sed -i 's\GLUF\GLU \g' *.pqr  
sed -i 's\GLYF\GLY \g' *.pqr  
sed -i 's\HISF\HIS \g' *.pqr  
sed -i 's\ILEF\ILE \g' *.pqr  
sed -i 's\LEUF\LEU \g' *.pqr  
sed -i 's\LYSF\LYS \g' *.pqr  
sed -i 's\METF\MET \g' *.pqr  
sed -i 's\PHEF\PHE \g' *.pqr  
sed -i 's\PROF\PRO \g' *.pqr  
sed -i 's\SERF\SER \g' *.pqr  
sed -i 's\THRF\THR \g' *.pqr  
sed -i 's\TRPF\TRP \g' *.pqr  
sed -i 's\TYRF\TYR \g' *.pqr  
sed -i 's\VALF\VAL \g' *.pqr  

sed -i 's\ASHA\ASH \g' *.pqr  
sed -i 's\ASHB\ASH \g' *.pqr  
sed -i 's\ASHC\ASH \g' *.pqr  
sed -i 's\ASHD\ASH \g' *.pqr  
sed -i 's\ASHE\ASH \g' *.pqr  
sed -i 's\ASHF\ASH \g' *.pqr  
sed -i 's\HIDA\HID \g' *.pqr  
sed -i 's\HIDB\HID \g' *.pqr  
sed -i 's\HIDC\HID \g' *.pqr  
sed -i 's\HIDD\HID \g' *.pqr  
sed -i 's\HIDE\HID \g' *.pqr  
sed -i 's\HIDF\HID \g' *.pqr  
sed -i 's\GLHA\GLH \g' *.pqr  
sed -i 's\GLHB\GLH \g' *.pqr  
sed -i 's\GLHC\GLH \g' *.pqr  
sed -i 's\GLHD\GLH \g' *.pqr  
sed -i 's\GLHE\GLH \g' *.pqr  
sed -i 's\GLHF\GLH \g' *.pqr  


sed -i 's\atpA\atp \g' *.pqr   
sed -i 's\adpA\adp \g' *.pqr   
sed -i 's\atpB\atp \g' *.pqr   
sed -i 's\adpB\adp \g' *.pqr   
sed -i 's\atpC\atp \g' *.pqr   
sed -i 's\adpC\adp \g' *.pqr   
sed -i 's\atpD\atp \g' *.pqr   
sed -i 's\adpD\adp \g' *.pqr   
sed -i 's\atpE\atp \g' *.pqr   
sed -i 's\adpE\adp \g' *.pqr   
sed -i 's\atpF\atp \g' *.pqr   
sed -i 's\adpF\adp \g' *.pqr   

sed -i 's\gtpA\gtp \g' *.pqr   
sed -i 's\gdpA\gdp \g' *.pqr   
sed -i 's\gtpB\gtp \g' *.pqr   
sed -i 's\gdpB\gdp \g' *.pqr   

sed -i 's\LIGA\LIG \g' *.pqr   
sed -i 's\LIGB\LIG \g' *.pqr   
sed -i 's\LIGC\LIG \g' *.pqr   
sed -i 's\LIGD\LIG \g' *.pqr   
sed -i 's\LIGE\LIG \g' *.pqr   
sed -i 's\LIGF\LIG \g' *.pqr   
sed -i 's\LIGG\LIG \g' *.pqr   

python rocklinC.py > result
rm *.pqr*
rm *.dx*
rm *.mc
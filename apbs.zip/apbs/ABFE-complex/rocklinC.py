import rocklinc
box=[80,80,80]  
lig_netq=-4.0
protein_netq=4.0
temp=300.0

import MDAnalysis as mda
u = mda.Universe('prod.tpr', 'prod.gro')
pqr = mda.Universe('prod.pqr')
u.add_TopologyAttr('radii')
u.atoms.radii = pqr.atoms.radii

correction = rocklinc.RocklinCorrection(box, lig_netq, protein_netq, temp, rocklinc.waters.TIP3P)

correction.make_APBS_input(u, 'resname atp',)

import subprocess
subprocess.run(["sed -i '/    glen/c\    glen 125.0 125.0 125.0' apbs.in"], shell = True, executable="/bin/bash") 
subprocess.run(["sed -i '/    dime/c\    dime 385 385 385' apbs.in"], shell = True, executable="/bin/bash")

correction.run_APBS(apbs_exe="/users/PAA0203/apoorvap/apbs/bin/apbs", apbs_in='apbs.in')

correction.read_APBS()

correction.compute()
correction.write('correction.txt')
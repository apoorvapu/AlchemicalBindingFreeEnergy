#!/bin/bash

python2 /users/PAA0203/apoorvap/alchemical-analysis/alchemical_analysis/alchemical_analysis.py -q xvg -p dhdl -t 300.0 -u kcal -m MBAR -w True -f 5 -s 500
#https://github.com/MobleyLab/alchemical-analysis
import rocklinc

box=[78,78,78]  

lig_netq=-4.0
protein_netq=4.0
temp=300.0
import MDAnalysis as mda
u = mda.Universe('ATP.tpr', 'enmin2.gro')
pqr = mda.Universe('ATP.pqr')
u.add_TopologyAttr('radii')
u.atoms.radii = pqr.atoms.radii

correction = rocklinc.RocklinCorrection(box, lig_netq, protein_netq, temp, rocklinc.waters.TIP3P)

correction.make_APBS_input(u, 'resname LIG',)

import subprocess
subprocess.run(["sed -i '/    glen/c\    glen 90.0 90.0 90.0' apbs.in"], shell = True, executable="/bin/bash") 
#subprocess.run(["sed -i '/    dime/c\    dime 385 385 385' apbs.in"], shell = True, executable="/bin/bash")

correction.run_APBS(apbs_exe="/users/PAA0203/apoorvap/apbs/bin/apbs", apbs_in='apbs.in')

correction.read_APBS()

correction.compute()
correction.write('correction_atp.txt')

del u, pqr, correction
subprocess.run(["rm *.dx*"], shell = True, executable="/bin/bash") 

###########ADP:
lig_netq=-3.0

u = mda.Universe('ADP.tpr', 'ADP.gro')
pqr = mda.Universe('ADP.pqr')
u.add_TopologyAttr('radii')
u.atoms.radii = pqr.atoms.radii

correction = rocklinc.RocklinCorrection(box, lig_netq, protein_netq, temp, rocklinc.waters.TIP3P)

correction.make_APBS_input(u, 'resname LIG',)

import subprocess
subprocess.run(["sed -i '/    glen/c\    glen 90.0 90.0 90.0' apbs.in"], shell = True, executable="/bin/bash") 
#subprocess.run(["sed -i '/    dime/c\    dime 385 385 385' apbs.in"], shell = True, executable="/bin/bash")


correction.run_APBS(apbs_exe="/users/PAA0203/apoorvap/apbs/bin/apbs", apbs_in='apbs.in')

correction.read_APBS()

correction.compute()
correction.write('correction_adp.txt')

del u, pqr, correction
subprocess.run(["rm *.pqr*"], shell = True, executable="/bin/bash") 
subprocess.run(["rm *.dx*"], shell = True, executable="/bin/bash") 

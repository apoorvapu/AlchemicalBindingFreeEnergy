!/bin/bash
source /home/purohit.52/gromacs-2022/gmx_installed_here/bin/GMXRC




for d in lambda.09 lambda.10 lambda.11 ; do
  d1=$(basename $d)
  lam="${d1##*.}"

  cd $d


  mkdir PROD
  cd PROD
 
  gmx grompp -maxwarn 1 -f ../../MDP/prod.$lam.mdp -c ../../enmin2.gro -r ../../enmin2.gro -p ../../gromacs.top -o prod.tpr


 
  cd ../../
done


 
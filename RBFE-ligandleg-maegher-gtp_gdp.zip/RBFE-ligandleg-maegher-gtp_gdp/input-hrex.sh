!/bin/bash
source /home/purohit.52/gromacs-2022-MPI/gmx_installed_here_MPI/bin/GMXRC
 
mpirun -np 12 gmx_mpi mdrun -gpu_id 4567 -nb gpu -pme gpu -bonded gpu -stepout 5000000 -s prod.tpr -deffnm prod -dhdl dhdl -replex 100 -nex 1000000 -multidir lambda.00/PROD/ lambda.01/PROD/ lambda.02/PROD/ lambda.03/PROD/ lambda.04/PROD/ lambda.05/PROD/ lambda.06/PROD/ lambda.07/PROD/ lambda.08/PROD/ lambda.09/PROD/ lambda.10/PROD/ lambda.11/PROD/ 

mpirun -np 12 gmx_mpi mdrun -gpu_id 4567 -nb gpu -pme gpu -bonded gpu -stepout 5000000 -s prod.tpr -deffnm prod -dhdl dhdl -replex 100 -nex 1000000 -multidir lambda.12/PROD/ lambda.13/PROD/ lambda.14/PROD/ lambda.15/PROD/ lambda.16/PROD/ lambda.17/PROD/ lambda.18/PROD/ lambda.19/PROD/ lambda.20/PROD/ lambda.21/PROD/ lambda.22/PROD/ lambda.23/PROD/  

!/bin/bash

echo "atomA=" "$(grep "adp     N7" gromacs.gro | gawk '{ print $(NF-3) }' | sed -n '1 p')" 
grep "adp     N7" gromacs.gro | gawk '{ print "A=" "[",$(NF-2),"," , $(NF-1),"," , $(NF),"]"}' 

echo "atomB=" "$(grep "adp     PA" gromacs.gro | gawk '{ print $(NF-3) }' | sed -n '1 p')" 
grep "adp     PA" gromacs.gro | gawk '{ print "B=" "[",$(NF-2),"," , $(NF-1),"," , $(NF),"]"}' 
 
echo "atomC=" "$(grep "adp     PB" gromacs.gro | gawk '{ print $(NF-3) }' | sed -n '1 p')" 
grep "adp     PB" gromacs.gro | gawk '{ print "C=" "[",$(NF-2),"," , $(NF-1),"," , $(NF),"]"}' 
 
#for ADPA -- using sed -n 2 -- for 2nd row (for ADPA use sed -n 1 .. and so on)

echo "atoma=" "$(grep " 40SER" gromacs.gro | grep " CA" | gawk '{ print $(NF-3) }' | sed -n '1 p')"  #2 in sed is for second row or monomer B
grep " 40SER" gromacs.gro | grep " CA" | sed -n '1 p' | gawk '{ print "a=" "[",$(NF-2),"," , $(NF-1),"," , $(NF),"]"}' 

echo "atomb=" "$(grep " 42SER" gromacs.gro | grep " CA" | gawk '{ print $(NF-3) }' | sed -n '1 p')"  #2 in sed is for second row or monomer B
grep " 42SER" gromacs.gro | grep " CA" | sed -n '1 p' | gawk '{ print "b=" "[",$(NF-2),"," , $(NF-1),"," , $(NF),"]"}' 

echo "atomc=" "$(grep " 44ASP" gromacs.gro | grep " CA" | gawk '{ print $(NF-3) }' | sed -n '1 p')"  #2 in sed is for second row or monomer B
grep " 44ASP" gromacs.gro | grep " CA" | sed -n '1 p' | gawk '{ print "c=" "[",$(NF-2),"," , $(NF-1),"," , $(NF),"]"}' 

